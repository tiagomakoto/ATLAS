import { create } from "zustand";

export const useAnalyticsStore = create((set) => ({
  walkForward: null,
  distribution: null,
  acf: null,
  fatTails: null,
  staleness: 0,

  update: (event) => {
    set((state) => {
      switch (event.type) {
        case "walk_forward":
          return { walkForward: event };

        case "distribution":
          return { distribution: event };

        case "acf":
          return { acf: event };

        case "fat_tails":
          return { fatTails: event };

        case "calibration_staleness":
          return { staleness: event.seconds };

        default:
          return {};
      }
    });
  }
}));