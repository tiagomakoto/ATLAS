import { create } from "zustand";

export const useSystemStore = create((set) => ({
  health: "green",
  modules: {},
  cycle: {},
  events: [],
  regime: null,
  alert: null,

  updateFromEvent: (event) => {
    set((state) => {
      switch (event.type) {
        case "health":
          return { health: event.status };

        case "module_status":
          return {
            modules: {
              ...state.modules,
              [event.module]: event.status,
            },
          };

        case "cycle_update":
          return { cycle: event.data };

        case "event":
          return { events: [event, ...state.events].slice(0, 50) };

        case "regime_update":
          return { regime: event };

        case "alert":
          return { alert: event };

        default:
          return {};
      }
    });
  },
}));