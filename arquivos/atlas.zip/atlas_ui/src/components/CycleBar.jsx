export default function CycleBar({ cycle }) {
  return (
    <div style={{
      padding: 8,
      background: "var(--atlas-surface)",
      border: "1px solid var(--atlas-border)",
      borderRadius: 2,
      fontFamily: "monospace",
      fontSize: 11
    }}>
      <div>Ativo: {cycle.ativo}</div>
      <div>Regime: {cycle.regime}</div>
      <div>Confiança: {cycle.regime_confianca}</div>
      <div>Posição: {cycle.posicao ? "ON" : "OFF"}</div>
      <div>PnL: {cycle.pnl}</div>
    </div>
  );
}