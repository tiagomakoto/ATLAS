import {
  ComposedChart, Line, Area, XAxis, YAxis, Tooltip
} from "recharts";

export default function WalkForwardChart({ data }) {
  if (!data) return null;

  const series = data.series.map(w => ({
    x: w.window_end,
    ir: w.ir_mean,
    band_low: w.ci_lower,
    band_high: w.ci_upper
  }));

  return (
    <div>
      <div style={{ fontFamily: "monospace", fontSize: 11 }}>
        Total N: {data.total_n}
      </div>

      <ComposedChart width={500} height={200} data={series}>
        <Area
          type="monotone"
          dataKey="band_high"
          stroke="none"
          fill="var(--atlas-blue)"
          fillOpacity={0.1}
        />
        <Area
          type="monotone"
          dataKey="band_low"
          stroke="none"
          fill="var(--atlas-bg)"
        />
        <Line
          type="monotone"
          dataKey="ir"
          stroke="var(--atlas-blue)"
          dot={false}
        />
        <XAxis dataKey="x" />
        <YAxis />
        <Tooltip />
      </ComposedChart>
    </div>
  );
}