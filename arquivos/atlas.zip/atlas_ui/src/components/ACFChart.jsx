import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ReferenceLine
} from "recharts";

export default function ACFChart({ data }) {
  if (!data) return null;

  const chartData = data.lags.map((lag, i) => ({
    lag,
    acf: data.values[i]
  }));

  const band = data.confidence_band;

  return (
    <div>
      <div style={{ fontFamily: "monospace", fontSize: 11 }}>
        ACF — N={data.n} | IC95% ±{band.toFixed(3)}
      </div>

      <BarChart width={400} height={160} data={chartData}>
        <Bar dataKey="acf" fill="var(--atlas-amber)" />
        <XAxis dataKey="lag" />
        <YAxis domain={[-1, 1]} />
        <ReferenceLine y={0} stroke="var(--atlas-border)" />
        <ReferenceLine y={band} stroke="var(--atlas-blue)" strokeDasharray="3 3" />
        <ReferenceLine y={-band} stroke="var(--atlas-blue)" strokeDasharray="3 3" />
        <Tooltip />
      </BarChart>
    </div>
  );
}