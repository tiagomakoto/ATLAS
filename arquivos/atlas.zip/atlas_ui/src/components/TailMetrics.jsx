export default function TailMetrics({ data }) {
  if (!data) return null;

  return (
    <div>
      <div>Média: {data.mean?.toFixed(4)}</div>
      <div>σ: {data.std?.toFixed(4)}</div>
      <div>Kurtosis: {data.kurtosis.toFixed(2)}</div>
      <div>P1%: {data.p1}</div>
      <div>P99%: {data.p99}</div>
    </div>
  );
}