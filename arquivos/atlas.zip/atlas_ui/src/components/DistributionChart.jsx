import {
  BarChart, Bar, XAxis, YAxis, Tooltip
} from "recharts";

export default function DistributionChart({ data }) {
  if (!data) return null;

  const chartData = data.histogram.map((v, i) => ({
    bin: data.bins[i]?.toFixed(3),
    count: v,
    pct: ((v / data.n) * 100).toFixed(1)
  }));

  return (
    <div>
      <div style={{ fontFamily: "monospace", fontSize: 11 }}>
        N={data.n}
      </div>

      <BarChart width={400} height={160} data={chartData}>
        <Bar dataKey="count" fill="var(--atlas-blue)" />
        <XAxis dataKey="bin" />
        <YAxis />
        <Tooltip />
      </BarChart>
    </div>
  );
}