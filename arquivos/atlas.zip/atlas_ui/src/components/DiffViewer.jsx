export default function DiffViewer({ diff }) {
  if (!diff || Object.keys(diff).length === 0) {
    return <div>Sem alterações</div>;
  }

  return (
    <div>
      {Object.entries(diff).map(([k, v]) => (
        <div key={k} style={{ fontFamily: "monospace", fontSize: 11 }}>
          <strong>{k}</strong>:
          <span style={{ color: "var(--atlas-red)" }}>
            {" "}{String(v.before)}
          </span>
          {" → "}
          <span style={{ color: "var(--atlas-green)" }}>
            {String(v.after)}
          </span>
        </div>
      ))}
    </div>
  );
}