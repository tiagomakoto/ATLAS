import { useState } from "react";
import AssetConfigPanel from "./AssetConfigPanel";
import DiffViewer from "./DiffViewer";
import ConfirmDialog from "./ConfirmDialog";

const ASSETS = ["VALE3", "PETR4"]; // ⚠️ backlog: vir do backend

export default function ConfigEditor() {
  const [asset, setAsset] = useState(ASSETS[0]);
  const [draft, setDraft] = useState({});
  const [diff, setDiff] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [description, setDescription] = useState("");

  function computeDiff() {
    fetch("/config/diff", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        data: { ativos: { [asset]: draft } }
      })
    })
      .then(r => r.json())
      .then(setDiff);
  }

  function requestSave() {
    if (!diff || Object.keys(diff).length === 0) {
      alert("Calcule o diff antes de salvar.");
      return;
    }
    setConfirmOpen(true);
  }

  function confirmSave() {
    if (!description.trim()) return;

    fetch("/config/update", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        data: { ativos: { [asset]: draft } },
        description: description.trim(),
        confirm: true
      })
    }).then(() => {
      setDiff(null);
      setDescription("");
      setConfirmOpen(false);
    });
  }

  return (
    <div style={{ fontFamily: "monospace", fontSize: 11 }}>
      <select
        value={asset}
        onChange={(e) => {
          setAsset(e.target.value);
          setDraft({});
          setDiff(null);
        }}
        style={{
          background: "var(--atlas-surface)",
          border: "1px solid var(--atlas-border)",
          color: "var(--atlas-text-primary)",
          padding: "2px 6px",
          borderRadius: 2
        }}
      >
        {ASSETS.map(a => <option key={a}>{a}</option>)}
      </select>

      <AssetConfigPanel
        asset={asset}
        draft={draft}
        onChange={setDraft}
      />

      <button onClick={computeDiff} style={{ marginTop: 8 }}>
        Ver diff
      </button>

      {diff && <DiffViewer diff={diff} />}

      {diff && Object.keys(diff).length > 0 && (
        <button onClick={requestSave} style={{ marginTop: 8 }}>
          Salvar alterações
        </button>
      )}

      <ConfirmDialog
        open={confirmOpen}
        diff={diff}
        description={description}
        onDescriptionChange={setDescription}
        onConfirm={confirmSave}
        onCancel={() => setConfirmOpen(false)}
      />
    </div>
  );
}