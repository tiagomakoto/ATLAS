import { useEffect, useState } from "react";

export default function ModeToggle() {
  const [mode, setMode] = useState("observe");

  useEffect(() => {
    fetch("/mode")
      .then(r => r.json())
      .then(data => setMode(data.mode));
  }, []);

  function toggle() {
    const next = mode === "observe" ? "live" : "observe";

    fetch("/mode", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ mode: next })
    })
      .then(r => r.json())
      .then(data => setMode(data.mode));
  }

  const isLive = mode === "live";

  return (
    <button
      onClick={toggle}
      style={{
        background: isLive
          ? "var(--atlas-red)"
          : "var(--atlas-amber)",
        color: "#fff",
        border: "none",
        fontFamily: "monospace",
        fontSize: 12,
        padding: "6px 14px",
        borderRadius: 2,
        cursor: "pointer"
      }}
    >
      {isLive
        ? "⚠ MODO EXECUÇÃO ATIVO — clique para OBSERVAÇÃO"
        : "● MODO OBSERVAÇÃO ATIVO — clique para EXECUÇÃO"}
    </button>
  );
}