function stalenessColor(seconds) {
  const minutes = seconds / 60;
  if (minutes < 30) return "var(--atlas-green)";
  if (minutes < 90) return "var(--atlas-amber)";
  return "var(--atlas-red)";
}

export default function FooterStatus({ regime, confidence, staleness }) {
  return (
    <div style={{
      position: "fixed",
      bottom: 0,
      width: "100%",
      background: "var(--atlas-surface)",
      borderTop: "1px solid var(--atlas-border)",
      padding: 6,
      fontSize: 11,
      fontFamily: "monospace"
    }}>
      Regime: {regime} |
      Confiança: {confidence} |
      <span style={{ color: stalenessColor(staleness) }}>
        Staleness: {Math.floor(staleness / 60)}min
      </span> |
      Fonte: ATLAS Engine
    </div>
  );
}