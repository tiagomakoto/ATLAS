import "./styles/tokens.css";

import { useCallback } from "react";

import useWebSocket from "./hooks/useWebSocket";
import { useSystemStore } from "./store/systemStore";
import { useAnalyticsStore } from "./store/analyticsStore";

import MainScreen from "./layouts/MainScreen";
import OfflineBanner from "./components/OfflineBanner";
import FooterStatus from "./components/FooterStatus";
import RegimeAlert from "./components/RegimeAlert";

// WS proxied by Vite — usa mesma origem do dev server
const WS_BASE = `${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.host}`;

export default function App() {
  const state = useSystemStore();
  const analytics = useAnalyticsStore();

  const handleEvent = useCallback((event) => {
    state.updateFromEvent(event);
    analytics.update(event);
  }, []);

  useWebSocket(`${WS_BASE}/ws/events`, handleEvent);
  useWebSocket(`${WS_BASE}/ws/modules`, handleEvent);
  useWebSocket(`${WS_BASE}/ws/logs`, handleEvent);

  return (
    <div style={{
      background: "var(--atlas-bg)",
      color: "var(--atlas-text-primary)",
      minHeight: "100vh"
    }}>
      <OfflineBanner />
      <RegimeAlert alert={state.alert} />
      <MainScreen state={state} analytics={analytics} />
      <FooterStatus
        regime={state.regime?.regime}
        confidence={state.regime?.confidence}
        staleness={analytics.staleness}
      />
    </div>
  );
}
