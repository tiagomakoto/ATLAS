import ConfigEditor from "../components/ConfigEditor";
import ExportReportButton from "../components/ExportReportButton";

export default function ActionPanel() {
  return (
    <div style={{
      border: "2px solid var(--atlas-amber)",
      background: "rgba(255,165,0,0.05)",
      padding: 10
    }}>
      <h4>Ações</h4>

      <ConfigEditor />
      <ExportReportButton />
    </div>
  );
}