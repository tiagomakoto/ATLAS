import HealthIndicator from "../components/HealthIndicator";
import ModuleGrid from "../components/ModuleGrid";
import CycleBar from "../components/CycleBar";
import EventFeed from "../components/EventFeed";
import WalkForwardChart from "../components/WalkForwardChart";
import DistributionChart from "../components/DistributionChart";
import ACFChart from "../components/ACFChart";
import TailMetrics from "../components/TailMetrics";
import TimeRangeSelector from "../components/TimeRangeSelector";
import { useState } from "react";

export default function ReadingPanel({ state, analytics }) {
  const [timeRange, setTimeRange] = useState("all");

  return (
    <div style={{
      border: "1px solid var(--atlas-border)",
      padding: 10,
      overflowY: "auto"
    }}>
      {/* 🎯 ELEMENTOS DINÂMICOS (chamam atenção) */}
      <HealthIndicator status={state.health} />

      {/* 📊 ESTADO DO SISTEMA (presentes, não invasivos) */}

      <div style={{ marginTop: 8 }}>
        <CycleBar cycle={state.cycle} />
      </div>

      <div style={{ marginTop: 8 }}>
        <ModuleGrid modules={state.modules} />
      </div>

      <div style={{ marginTop: 8 }}>
        <EventFeed events={state.events} />
      </div>

      {/* 📈 ANÁLISE COMPLETA (sem navegação) */}
      <div style={{
        marginTop: 12,
        borderTop: "1px solid var(--atlas-border)",
        paddingTop: 8
      }}>
        <TimeRangeSelector value={timeRange} onChange={setTimeRange} />

        <WalkForwardChart data={analytics.walkForward} />
        <DistributionChart data={analytics.distribution} />
        <ACFChart data={analytics.acf} />
        <TailMetrics data={analytics.fatTails} />
      </div>
    </div>
  );
}