import ModeToggle from "../components/ModeToggle";
import Terminal from "../components/Terminal";
import ReadingPanel from "./ReadingPanel";
import ActionPanel from "./ActionPanel";

export default function MainScreen({ state, analytics }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateRows: "auto 1fr auto",
      minHeight: "100vh",
      background: "var(--atlas-bg)"
    }}>
      {/* TOPO — CONTROLE */}
      <div style={{
        borderBottom: "2px solid var(--atlas-red)",
        padding: "10px 16px",
        display: "flex",
        alignItems: "center",
        gap: 12
      }}>
        <span style={{
          fontFamily: "monospace",
          fontSize: 13,
          color: "var(--atlas-text-secondary)",
          letterSpacing: 2
        }}>
          ATLAS
        </span>
        <ModeToggle />
      </div>

      {/* CENTRO — LEITURA + AÇÕES */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "2fr 1fr",
        gap: 12,
        padding: 12,
        overflow: "hidden"
      }}>
        <ReadingPanel state={state} analytics={analytics} />
        <ActionPanel />
      </div>

      {/* BASE — TERMINAL */}
      <div style={{ borderTop: "1px solid var(--atlas-border)" }}>
        <Terminal />
      </div>
    </div>
  );
}
