import asyncio
from asyncio import Queue

event_queue: Queue = Queue()

async def publish_event(event: dict):
    await event_queue.put(event)

def emit_event(event: dict):
    """Compatível com contexto síncrono e assíncrono."""
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(publish_event(event))
    except RuntimeError:
        # fallback seguro — sem loop ativo
        asyncio.run(publish_event(event))

async def event_dispatcher():
    """Loop central que envia eventos para os WebSockets."""
    from api.websocket.stream import manager

    while True:
        event = await event_queue.get()
        await manager.broadcast(event)