from pydantic import BaseModel, Field
from typing import Optional, Dict


class AssetConfig(BaseModel):
    take_profit: float = Field(..., gt=0, lt=1)
    stop_loss: float = Field(..., gt=0)
    regime_estrategia: Dict[str, Optional[str]]


class ConfigSchema(BaseModel):
    ativos: Dict[str, AssetConfig]


def validate_config(data: dict) -> dict:
    """
    Valida o config completo contra o schema.
    Lança ValidationError (Pydantic) se inválido.
    Retorna o dict original se válido.
    """
    ConfigSchema(**data)
    return data
