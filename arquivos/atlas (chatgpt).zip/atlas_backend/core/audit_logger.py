import json
from pathlib import Path

LOG_PATH = Path("storage/logs/audit.log")

def load_audit_log(n: int = 50):
    """
    Lê as últimas n entradas do log de auditoria.
    Retorna lista de dicts — entradas malformadas são ignoradas.
    """
    if not LOG_PATH.exists():
        return []

    entries = []

    with open(LOG_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

    return entries[-n:]