import ModeToggle from "../components/ModeToggle";
import HealthIndicator from "../components/HealthIndicator";
import RegimeAlert from "../components/RegimeAlert";
import Terminal from "../components/Terminal";
import ConfigEditor from "../components/ConfigEditor";

export default function MainScreen({ state, analytics }) {
  return (
    <div style={{
      display: "grid",
      gridTemplateRows: "auto 1fr auto",
      height: "100vh",
      background: "var(--atlas-bg)"
    }}>
      
      {/* TOPO — CONTROLE */}
      <div style={{
        borderBottom: "2px solid var(--atlas-red)",
        padding: 12
      }}>
        <ModeToggle />
      </div>

      {/* CENTRO — LEITURA */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "2fr 1fr",
        gap: 12,
        padding: 12
      }}>
        <ReadingPanel state={state} analytics={analytics} />
        <ActionPanel />
      </div>

      {/* BASE — TERMINAL */}
      <div style={{
        borderTop: "1px solid var(--atlas-border)"
      }}>
        <Terminal />
      </div>
    </div>
  );
}