import { useEffect } from "react";

export default function useWebSocket(url, onMessage) {
  useEffect(() => {
    const ws = new WebSocket(url);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        onMessage(data);
      } catch (e) {
        console.error("WS parse error", e);
      }
    };

    ws.onerror = (err) => console.error("WS error", err);
    ws.onclose = () => console.warn("WS closed:", url);

    return () => ws.close();
  }, [url]);
}