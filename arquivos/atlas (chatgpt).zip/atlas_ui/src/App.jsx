import "./styles/tokens.css";

import { useCallback } from "react";

import useWebSocket from "./hooks/useWebSocket";
import { useSystemStore } from "./store/systemStore";
import { useAnalyticsStore } from "./store/analyticsStore";

import MainScreen from "./layouts/MainScreen";
import OfflineBanner from "./components/OfflineBanner";

import HealthIndicator from "./components/HealthIndicator";
import ModuleGrid from "./components/ModuleGrid";
import CycleBar from "./components/CycleBar";
import EventFeed from "./components/EventFeed";
import RegimeAlert from "./components/RegimeAlert";

import WalkForwardChart from "./components/WalkForwardChart";
import DistributionChart from "./components/DistributionChart";
import ACFChart from "./components/ACFChart";
import TailMetrics from "./components/TailMetrics";
import TimeRangeSelector from "./components/TimeRangeSelector";
import FooterStatus from "./components/FooterStatus";

import ConfigEditor from "./components/ConfigEditor";
import Terminal from "./components/Terminal";
import ModeToggle from "./components/ModeToggle";



export default function App() {
  const state = useSystemStore();
  const analytics = useAnalyticsStore();

  const [timeRange, setTimeRange] = useState("all");

  const WS_BASE = "ws://localhost:8000";

  const handleEvent = useCallback((event) => {
    state.updateFromEvent(event);
    analytics.update(event);
  }, []);

  useWebSocket(`${WS_BASE}/ws/events`, handleEvent);
  useWebSocket(`${WS_BASE}/ws/modules`, handleEvent);
  useWebSocket(`${WS_BASE}/ws/logs`, handleEvent);

  return (
    <div style={{
      padding: 16,
      background: "var(--atlas-bg)",
      color: "var(--atlas-text-primary)",
      minHeight: "100vh"
    }}>
      <ModeToggle />

      <HealthIndicator status={state.health} />

      <h3>Módulos</h3>
      <ModuleGrid modules={state.modules} />

      <h3>Ciclo</h3>
      <CycleBar cycle={state.cycle} />

      <h3>Eventos</h3>
      <EventFeed events={state.events} />

      <RegimeAlert alert={state.alert} />

      <h3>Análise</h3>
      <TimeRangeSelector value={timeRange} onChange={setTimeRange} />

      <WalkForwardChart data={analytics.walkForward} />
      <DistributionChart data={analytics.distribution} />
      <ACFChart data={analytics.acf} />
      <TailMetrics data={analytics.fatTails} />

      <h3>Configuração</h3>
      <ConfigEditor />

      <h3>Terminal</h3>
      <Terminal />

      <OfflineBanner />
      <MainScreen state={state} analytics={analytics} />

      <FooterStatus
        regime={state.regime?.regime}
        confidence={state.regime?.confidence}
        staleness={analytics.staleness}
      />
    </div>
  );
}