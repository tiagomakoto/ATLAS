"use client"

import { useState } from "react"
import { GlobalBar } from "@/components/atlas/global-bar"
import { SidebarNav } from "@/components/atlas/sidebar-nav"
import { ModuleStatus } from "@/components/atlas/module-status"
import { MainPanel } from "@/components/atlas/main-panel"
import { EventsPanel } from "@/components/atlas/events-panel"
import { Footer } from "@/components/atlas/footer"
import { TerminalOverlay } from "@/components/atlas/terminal-overlay"

type NavItem = "operational" | "analysis" | "configuration" | "terminal"

export default function AtlasDashboard() {
  const [isExecutionMode, setIsExecutionMode] = useState(false)
  const [isTerminalOpen, setIsTerminalOpen] = useState(false)
  const [activeNav, setActiveNav] = useState<NavItem>("operational")
  const hasTerminalErrors = true // Simulated unread errors

  const handleNavigate = (item: NavItem) => {
    if (item === "terminal") {
      setIsTerminalOpen(true)
    } else {
      setActiveNav(item)
    }
  }

  return (
    <div className="min-h-screen bg-atlas-bg text-atlas-text-primary">
      {/* Global Bar */}
      <GlobalBar
        isExecutionMode={isExecutionMode}
        onToggleMode={() => setIsExecutionMode(!isExecutionMode)}
        hasTerminalErrors={hasTerminalErrors}
        onOpenTerminal={() => setIsTerminalOpen(true)}
        onOpenConfig={() => {}}
        onOpenMenu={() => {}}
      />

      {/* Sidebar Navigation */}
      <SidebarNav activeItem={activeNav} onNavigate={handleNavigate} />

      {/* Main Content Area */}
      <main className="pt-[72px] pb-6 pl-12">
        <div className="flex h-[calc(100vh-72px-24px)]">
          {/* Left Column - Module Status */}
          <div className="w-[160px] shrink-0 border-r border-atlas-border overflow-y-auto">
            <ModuleStatus />
          </div>

          {/* Center Column - Main Panel */}
          <div className="flex-1 overflow-y-auto">
            <MainPanel isExecutionMode={isExecutionMode} />
          </div>

          {/* Right Column - Events Panel */}
          <div className="w-[320px] shrink-0 overflow-hidden">
            <EventsPanel />
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />

      {/* Terminal Overlay */}
      <TerminalOverlay
        isOpen={isTerminalOpen}
        onClose={() => setIsTerminalOpen(false)}
        isExecutionMode={isExecutionMode}
      />
    </div>
  )
}
