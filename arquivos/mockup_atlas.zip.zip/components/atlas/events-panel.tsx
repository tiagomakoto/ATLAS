"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

type TabType = "events" | "audit"

interface Event {
  time: string
  message: string
  type: "system" | "ceo"
}

const events: Event[] = [
  { time: "14:23", message: "ORBIT → NEUTRO_BULL", type: "system" },
  { time: "14:21", message: "GATE → OPERATE", type: "system" },
  { time: "14:20", message: "Cycle 2026-03 started", type: "system" },
  { time: "14:15", message: "[CEO] TP edited: 0.85 → 0.90", type: "ceo" },
  { time: "14:02", message: "TUNE calibrated", type: "system" },
  { time: "13:45", message: "[CEO] Sizing adjusted: 0.8 → 1.0", type: "ceo" },
  { time: "13:30", message: "BOOK position opened", type: "system" },
  { time: "13:28", message: "FIRE signal triggered", type: "system" },
  { time: "13:15", message: "EDGE calculation complete", type: "system" },
  { time: "13:00", message: "Session started", type: "system" },
]

export function EventsPanel() {
  const [activeTab, setActiveTab] = useState<TabType>("events")

  const filteredEvents =
    activeTab === "audit"
      ? events.filter((e) => e.type === "ceo")
      : events

  return (
    <aside className="flex flex-col h-full bg-atlas-surface border-l border-atlas-border">
      {/* Tab Switcher */}
      <div className="flex border-b border-atlas-border">
        <TabButton
          active={activeTab === "events"}
          onClick={() => setActiveTab("events")}
        >
          EVENTS
        </TabButton>
        <TabButton
          active={activeTab === "audit"}
          onClick={() => setActiveTab("audit")}
        >
          AUDIT
        </TabButton>
      </div>

      {/* Event Stream */}
      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {filteredEvents.map((event, index) => (
            <EventItem key={index} event={event} />
          ))}
        </div>
      </div>
    </aside>
  )
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex-1 px-4 py-2 font-mono text-xs font-medium transition-colors",
        active
          ? "text-atlas-text-primary border-b-2 border-atlas-blue"
          : "text-atlas-text-secondary hover:text-atlas-text-primary"
      )}
    >
      {children}
    </button>
  )
}

function EventItem({ event }: { event: Event }) {
  return (
    <div className="flex items-start gap-2 px-2 py-1.5 rounded-sm hover:bg-atlas-bg/50">
      <span className="font-mono text-[10px] text-atlas-text-secondary shrink-0">
        {event.time}
      </span>
      <span
        className={cn(
          "font-mono text-[11px] leading-tight",
          event.type === "ceo" ? "text-atlas-amber" : "text-atlas-text-primary"
        )}
      >
        {event.message}
      </span>
    </div>
  )
}
