"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface MainPanelProps {
  isExecutionMode: boolean
}

export function MainPanel({ isExecutionMode }: MainPanelProps) {
  return (
    <div className="flex flex-col gap-3 p-3">
      <GateDecisionCard />
      <ReflectStateCard />
      <OpenPositionCard isExecutionMode={isExecutionMode} />
    </div>
  )
}

function Card({
  title,
  children,
  className,
}: {
  title: string
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        "bg-atlas-surface border border-atlas-border rounded-sm",
        className
      )}
    >
      <div className="px-3 py-2 border-b border-atlas-border">
        <h3 className="font-sans text-xs font-medium text-atlas-text-secondary uppercase tracking-wider">
          {title}
        </h3>
      </div>
      <div className="p-3">{children}</div>
    </div>
  )
}

function DataRow({
  label,
  value,
  highlight,
  mono = true,
}: {
  label: string
  value: string | React.ReactNode
  highlight?: "green" | "red" | "amber" | "blue"
  mono?: boolean
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-atlas-text-secondary text-xs">{label}</span>
      <span
        className={cn(
          "text-xs",
          mono && "font-mono",
          highlight === "green" && "text-atlas-green",
          highlight === "red" && "text-atlas-red",
          highlight === "amber" && "text-atlas-amber",
          highlight === "blue" && "text-atlas-blue",
          !highlight && "text-atlas-text-primary"
        )}
      >
        {value}
      </span>
    </div>
  )
}

function GateDecisionCard() {
  return (
    <Card title="GATE Decision">
      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-3">
          <span className="font-mono text-sm text-atlas-text-secondary">GATE →</span>
          <span className="font-mono text-sm font-semibold text-atlas-green">OPERATE</span>
        </div>
        <DataRow label="Regime" value="NEUTRO_BULL" />
        <DataRow label="IR Expected" value="0.680" />
        <DataRow label="IR Realized" value="2.548" highlight="green" />
        <DataRow label="Anos válidos" value="2023, 2024, 2025" />
        <div className="pt-2 mt-2 border-t border-atlas-border">
          <p className="font-mono text-[10px] text-atlas-text-secondary">
            ORBIT v3.3 | 2026-03-22
          </p>
        </div>
      </div>
    </Card>
  )
}

function ReflectStateCard() {
  return (
    <Card title="REFLECT State">
      <div className="space-y-2">
        <div className="flex items-center gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-atlas-text-secondary">State:</span>
            <span className="font-mono text-lg font-bold text-atlas-text-primary">B</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-atlas-text-secondary">Score:</span>
            <span className="font-mono text-sm text-atlas-amber">-0.125</span>
          </div>
        </div>
        <DataRow label="Acceleration" value="-0.169" />
        <DataRow label="Delta IR" value="+0.685" highlight="green" />
        <DataRow
          label="Permanent Block"
          value={
            <span className="flex items-center gap-1">
              <span>❌</span>
              <span className="text-atlas-text-secondary">inactive</span>
            </span>
          }
        />
      </div>
    </Card>
  )
}

function OpenPositionCard({ isExecutionMode }: { isExecutionMode: boolean }) {
  const [isClosing, setIsClosing] = useState(false)

  const handleClose = () => {
    setIsClosing(true)
    setTimeout(() => {
      setIsClosing(false)
    }, 2000)
  }

  return (
    <Card title="Open Position">
      <div className="space-y-2">
        <div className="flex items-center justify-between mb-3">
          <span className="font-mono text-sm font-semibold text-atlas-text-primary">
            Bull Put Spread
          </span>
          <span className="font-mono text-xs text-atlas-blue">VALE3</span>
        </div>
        <DataRow label="Strike" value="R$58 / R$55" />
        <DataRow label="Expiry" value="2026-04-17" />
        <DataRow label="P&L" value="+R$420 (+47% of premium)" highlight="green" />
        <div className="flex items-center gap-4 pt-1">
          <DataRow label="TP" value="90%" />
          <DataRow label="STOP" value="2.0x" />
        </div>

        <div className="pt-3 mt-3 border-t border-atlas-border">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button
                disabled={!isExecutionMode || isClosing}
                className={cn(
                  "w-full py-2 px-4 font-mono text-xs font-medium rounded-sm transition-colors",
                  isExecutionMode
                    ? "bg-atlas-red text-white hover:bg-atlas-red/80 cursor-pointer"
                    : "bg-atlas-surface border border-atlas-border text-atlas-text-secondary cursor-not-allowed"
                )}
              >
                {isClosing ? "CLOSING..." : "CLOSE POSITION"}
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-atlas-surface border-atlas-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-sans text-atlas-text-primary">
                  Confirm Position Close
                </AlertDialogTitle>
                <AlertDialogDescription className="font-mono text-xs text-atlas-text-secondary">
                  You are about to close the Bull Put Spread position on VALE3.
                  <br />
                  Current P&L: +R$420 (+47% of premium)
                  <br />
                  <br />
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="font-mono text-xs bg-atlas-bg border-atlas-border text-atlas-text-secondary hover:text-atlas-text-primary hover:bg-atlas-bg">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleClose}
                  className="font-mono text-xs bg-atlas-red text-white hover:bg-atlas-red/80"
                >
                  Confirm Close
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          {!isExecutionMode && (
            <p className="mt-2 font-mono text-[10px] text-atlas-amber text-center">
              Switch to EXECUTION MODE to enable actions
            </p>
          )}
        </div>
      </div>
    </Card>
  )
}
