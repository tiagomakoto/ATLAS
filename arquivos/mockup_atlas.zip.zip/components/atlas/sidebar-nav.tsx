"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Monitor, BarChart3, Settings, Terminal, ChevronLeft, ChevronRight } from "lucide-react"

type NavItem = "operational" | "analysis" | "configuration" | "terminal"

interface SidebarNavProps {
  activeItem: NavItem
  onNavigate: (item: NavItem) => void
}

const navItems = [
  { id: "operational" as const, icon: Monitor, label: "Operational" },
  { id: "analysis" as const, icon: BarChart3, label: "Analysis" },
  { id: "configuration" as const, icon: Settings, label: "Configuration" },
  { id: "terminal" as const, icon: Terminal, label: "Terminal" },
]

export function SidebarNav({ activeItem, onNavigate }: SidebarNavProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <nav
      className={cn(
        "fixed left-0 top-[72px] bottom-0 z-40 flex flex-col bg-atlas-bg border-r border-atlas-border transition-all duration-200",
        isExpanded ? "w-48" : "w-12"
      )}
    >
      {/* Nav Items */}
      <div className="flex-1 py-2">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = activeItem === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "flex items-center gap-3 w-full px-3 py-2.5 transition-colors",
                isActive
                  ? "bg-atlas-surface text-atlas-text-primary border-r-2 border-atlas-blue"
                  : "text-atlas-text-secondary hover:text-atlas-text-primary hover:bg-atlas-surface/50"
              )}
              title={!isExpanded ? item.label : undefined}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {isExpanded && (
                <span className="font-sans text-xs font-medium truncate">
                  {item.label}
                </span>
              )}
            </button>
          )
        })}
      </div>

      {/* Expand Toggle */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-center py-3 border-t border-atlas-border text-atlas-text-secondary hover:text-atlas-text-primary transition-colors"
        aria-label={isExpanded ? "Collapse sidebar" : "Expand sidebar"}
      >
        {isExpanded ? (
          <ChevronLeft className="w-4 h-4" />
        ) : (
          <ChevronRight className="w-4 h-4" />
        )}
      </button>
    </nav>
  )
}
