"use client"

import { useState, useRef, useEffect } from "react"
import { X } from "lucide-react"
import { cn } from "@/lib/utils"

interface TerminalOverlayProps {
  isOpen: boolean
  onClose: () => void
  isExecutionMode: boolean
}

interface TerminalLine {
  type: "input" | "output" | "error"
  content: string
}

const initialHistory: TerminalLine[] = [
  { type: "input", content: 'gate.check("VALE3")' },
  { type: "output", content: "GATE [2026-03-24 14:23] VALE3 → OPERATE" },
  { type: "output", content: "  IR expected NEUTRO_BULL: 0.680" },
  { type: "output", content: "  IR realized: 2.548" },
  { type: "output", content: "  anos_validos: [2023, 2024, 2025]" },
]

export function TerminalOverlay({
  isOpen,
  onClose,
  isExecutionMode,
}: TerminalOverlayProps) {
  const [history, setHistory] = useState<TerminalLine[]>(initialHistory)
  const [input, setInput] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
  }, [isOpen])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [history])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const newHistory: TerminalLine[] = [
      ...history,
      { type: "input", content: input },
    ]

    // Simulate command responses
    if (input.startsWith("gate.")) {
      newHistory.push({
        type: "output",
        content: `GATE [${new Date().toISOString().slice(0, 16).replace("T", " ")}] Command executed`,
      })
    } else if (input.startsWith("reflect.")) {
      newHistory.push({
        type: "output",
        content: "REFLECT State: B | Score: -0.125",
      })
    } else if (input === "help") {
      newHistory.push({
        type: "output",
        content: "Available commands: gate.check(asset), reflect.state(), orbit.regime(), tune.calibrate()",
      })
    } else if (input === "clear") {
      setHistory([])
      setInput("")
      return
    } else {
      newHistory.push({
        type: "error",
        content: `Unknown command: ${input}`,
      })
    }

    setHistory(newHistory)
    setInput("")
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 h-[60vh] bg-atlas-bg border-t border-atlas-border flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-atlas-border bg-atlas-surface">
        <div className="flex items-center gap-4">
          <span className="font-mono text-xs text-atlas-text-primary">
            ATLAS TERMINAL
          </span>
          <span
            className={cn(
              "px-2 py-0.5 font-mono text-[10px] rounded-sm",
              isExecutionMode
                ? "bg-atlas-red/20 text-atlas-red"
                : "bg-atlas-amber/20 text-atlas-amber"
            )}
          >
            {isExecutionMode ? "EXECUTION MODE" : "OBSERVATION MODE"}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-atlas-text-secondary hover:text-atlas-text-primary transition-colors"
          aria-label="Close terminal"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Terminal Content */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 font-mono text-xs"
      >
        {history.map((line, index) => (
          <div key={index} className="leading-relaxed">
            {line.type === "input" ? (
              <div className="flex items-start gap-2">
                <span className="text-atlas-blue">{">"}</span>
                <span className="text-atlas-text-primary">{line.content}</span>
              </div>
            ) : line.type === "error" ? (
              <div className="text-atlas-red pl-4">{line.content}</div>
            ) : (
              <div className="text-atlas-text-secondary pl-4">{line.content}</div>
            )}
          </div>
        ))}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="border-t border-atlas-border">
        <div className="flex items-center px-4 py-2">
          <span className="font-mono text-xs text-atlas-blue mr-2">{">"}</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 bg-transparent font-mono text-xs text-atlas-text-primary outline-none placeholder:text-atlas-text-secondary"
            placeholder="Enter command..."
            autoComplete="off"
            spellCheck={false}
          />
        </div>
      </form>

      {/* Footer */}
      <div className="flex items-center justify-between px-4 py-2 border-t border-atlas-border bg-atlas-surface">
        <button className="px-3 py-1.5 font-mono text-[10px] text-atlas-blue border border-atlas-blue/30 rounded-sm hover:bg-atlas-blue/10 transition-colors">
          EXPORT SESSION REPORT
        </button>
        <span className="font-mono text-[10px] text-atlas-text-secondary">
          Type &quot;help&quot; for available commands
        </span>
      </div>
    </div>
  )
}
