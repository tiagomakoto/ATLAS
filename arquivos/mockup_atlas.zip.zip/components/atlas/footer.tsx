export function Footer() {
  const now = new Date()
  const timestamp = now.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  })

  return (
    <footer className="fixed bottom-0 left-12 right-0 h-6 flex items-center justify-between px-4 bg-atlas-bg border-t border-atlas-border z-30">
      <div className="flex items-center gap-4 font-mono text-[10px] text-atlas-text-secondary">
        <span>source: COTAHIST B3</span>
        <span className="text-atlas-border">|</span>
        <span>module: ORBIT v3.3</span>
        <span className="text-atlas-border">|</span>
        <span>updated: {timestamp}</span>
      </div>
      <span className="font-mono text-[10px] text-atlas-text-secondary">© ATLAS</span>
    </footer>
  )
}
