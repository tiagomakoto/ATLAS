"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { ChevronDown } from "lucide-react"

interface Module {
  id: string
  name: string
  status: "operational" | "warning" | "error"
  details?: string
}

const modules: Module[] = [
  { id: "tape", name: "TAPE", status: "operational", details: "Last update: 14:23:01" },
  { id: "orbit", name: "ORBIT", status: "operational", details: "v3.3 | NEUTRO_BULL" },
  { id: "fire", name: "FIRE", status: "operational", details: "Idle" },
  { id: "book", name: "BOOK", status: "operational", details: "1 open position" },
  { id: "edge", name: "EDGE", status: "operational", details: "IR: 2.548" },
  { id: "gate", name: "GATE", status: "operational", details: "OPERATE" },
  { id: "tune", name: "TUNE", status: "operational", details: "Last calibration: 14:02" },
]

export function ModuleStatus() {
  const [expanded, setExpanded] = useState<string | null>(null)

  return (
    <aside className="flex flex-col gap-1 p-2">
      <h2 className="font-sans text-xs font-medium text-atlas-text-secondary uppercase tracking-wider px-2 mb-2">
        Modules
      </h2>
      {modules.map((module) => (
        <ModulePill
          key={module.id}
          module={module}
          isExpanded={expanded === module.id}
          onToggle={() => setExpanded(expanded === module.id ? null : module.id)}
        />
      ))}
    </aside>
  )
}

function ModulePill({
  module,
  isExpanded,
  onToggle,
}: {
  module: Module
  isExpanded: boolean
  onToggle: () => void
}) {
  const statusColor = {
    operational: "bg-atlas-green",
    warning: "bg-atlas-amber",
    error: "bg-atlas-red",
  }

  return (
    <div className="flex flex-col">
      <button
        onClick={onToggle}
        className={cn(
          "flex items-center justify-between gap-2 px-3 py-2 rounded-sm transition-colors",
          "bg-atlas-surface border border-atlas-border",
          "hover:border-atlas-text-secondary/30",
          isExpanded && "border-atlas-text-secondary/30"
        )}
      >
        <div className="flex items-center gap-2">
          <span className={cn("w-2 h-2 rounded-full", statusColor[module.status])} />
          <span className="font-mono text-xs text-atlas-text-primary">{module.name}</span>
        </div>
        <ChevronDown
          className={cn(
            "w-3 h-3 text-atlas-text-secondary transition-transform",
            isExpanded && "rotate-180"
          )}
        />
      </button>
      {isExpanded && module.details && (
        <div className="px-3 py-2 mt-1 bg-atlas-bg border border-atlas-border rounded-sm">
          <p className="font-mono text-[10px] text-atlas-text-secondary">{module.details}</p>
        </div>
      )}
    </div>
  )
}
