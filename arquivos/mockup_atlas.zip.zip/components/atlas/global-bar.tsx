"use client"

import { Settings, Menu, Terminal } from "lucide-react"
import { cn } from "@/lib/utils"

interface GlobalBarProps {
  isExecutionMode: boolean
  onToggleMode: () => void
  hasTerminalErrors: boolean
  onOpenTerminal: () => void
  onOpenConfig: () => void
  onOpenMenu: () => void
}

export function GlobalBar({
  isExecutionMode,
  onToggleMode,
  hasTerminalErrors,
  onOpenTerminal,
  onOpenConfig,
  onOpenMenu,
}: GlobalBarProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-atlas-bg border-b border-atlas-border">
      {/* Row 1: Logo + Mode Banner + Icons */}
      <div className="flex items-center h-10">
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 min-w-[200px]">
          <div className="w-6 h-6 bg-atlas-text-primary flex items-center justify-center">
            <span className="font-mono text-xs font-bold text-atlas-bg">A</span>
          </div>
          <span className="font-sans font-semibold text-sm tracking-wide text-atlas-text-primary">
            ATLAS
          </span>
        </div>

        {/* Mode Banner */}
        <button
          onClick={onToggleMode}
          className={cn(
            "flex-1 h-full flex items-center justify-center gap-2 font-mono text-xs font-medium transition-colors cursor-pointer",
            isExecutionMode
              ? "bg-atlas-red/20 text-atlas-red border-y border-atlas-red/30"
              : "bg-atlas-amber/20 text-atlas-amber border-y border-atlas-amber/30"
          )}
        >
          {isExecutionMode ? (
            <>
              <span className="text-base">⚠</span>
              <span>EXECUTION MODE — actions are live</span>
            </>
          ) : (
            <>
              <span className="inline-block w-2 h-2 rounded-full bg-atlas-amber" />
              <span>OBSERVATION MODE — no actions will execute</span>
            </>
          )}
        </button>

        {/* Icons */}
        <div className="flex items-center gap-1 px-4 min-w-[200px] justify-end">
          <button
            onClick={onOpenConfig}
            className="p-2 text-atlas-text-secondary hover:text-atlas-text-primary transition-colors"
            aria-label="Configuration"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenMenu}
            className="p-2 text-atlas-text-secondary hover:text-atlas-text-primary transition-colors"
            aria-label="Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenTerminal}
            className="relative p-2 text-atlas-text-secondary hover:text-atlas-text-primary transition-colors"
            aria-label="Terminal"
          >
            <Terminal className="w-4 h-4" />
            {hasTerminalErrors && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-atlas-red" />
            )}
          </button>
        </div>
      </div>

      {/* Row 2: Status Bar */}
      <div className="flex items-center h-8 px-4 bg-atlas-surface border-t border-atlas-border overflow-x-auto">
        <div className="flex items-center gap-4 font-mono text-xs whitespace-nowrap">
          <StatusItem label="Asset" value="VALE3" />
          <Separator />
          <StatusItem label="Regime" value="NEUTRO_BULL" />
          <Separator />
          <StatusItem label="Sizing" value="1.0" />
          <Separator />
          <StatusItem label="Position" value="OPEN" highlight="green" />
          <Separator />
          <StatusItem label="P&L" value="+R$420" highlight="green" />
          <Separator />
          <StatusItem label="Health" value="🟢" />
          <Separator />
          <StatusItem label="GATE" value="OPERATE" highlight="green" />
          <Separator />
          <StatusItem label="REFLECT" value="B" />
          <Separator />
          <StatusItem label="Staleness" value="🟢 2d" />
        </div>
      </div>
    </header>
  )
}

function StatusItem({
  label,
  value,
  highlight,
}: {
  label: string
  value: string
  highlight?: "green" | "red" | "amber"
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-atlas-text-secondary">{label}:</span>
      <span
        className={cn(
          highlight === "green" && "text-atlas-green",
          highlight === "red" && "text-atlas-red",
          highlight === "amber" && "text-atlas-amber",
          !highlight && "text-atlas-text-primary"
        )}
      >
        {value}
      </span>
    </div>
  )
}

function Separator() {
  return <span className="text-atlas-border">|</span>
}
